import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private apiUrl = "http://localhost:3000/category"; // API URL

  http = inject(HttpClient);

  constructor() { }

  // Get all categories from the server
  getAllCategories(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  // Delete a specific category
  deleteCategory(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  // Edit an existing category
  editCategory(id: string, updatedCategory: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, updatedCategory);
  }

  // Add a new category
  addCategory(newCategory: any): Observable<any> {
    return this.http.post(this.apiUrl, newCategory);
  }
}
