import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../environment/wishlist-environment';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {
  private apiUrl = `${environment.apiUrl}/wishlist`;

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    console.log("Token being sent:", token);  // Log the token to verify
    
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
  }
  
  getWishlist(userId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${userId}`, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  addProductToWishlist(userId: string, productId: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/add`, { userId, productId }, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  // Updated to use DELETE for removing a product from the wishlist
  removeProductFromWishlist(userId: string, productId: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/remove`, {
      headers: this.getHeaders(),
      body: { userId, productId }  // Sending the body in DELETE request
    }).pipe(catchError(this.handleError));
  }

  private handleError(error: any): Observable<never> {
    console.error('WishlistService error:', error);
    return throwError(() => error);
  }
}
