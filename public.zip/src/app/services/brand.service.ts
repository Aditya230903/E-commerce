import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BrandService {
  private apiUrl = 'http://localhost:3000/brands'; // API URL

  http = inject(HttpClient);

  constructor() { }

  getAllBrands(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  addBrand(newBrand: { name: string }): Observable<any> {
    return this.http.post(this.apiUrl, newBrand);
  }

  deleteBrand(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  editBrand(id: string, updatedBrand: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, updatedBrand);
  }
}
