import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Product } from '../common/product';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = 'http://localhost:3000/product';
  private uploadUrl = 'http://localhost:3000/upload';

  constructor(private http: HttpClient, @Inject(PLATFORM_ID) private platformId: Object) {}

  // Helper method to create headers with Authorization token
  private createAuthHeaders(): HttpHeaders {
    let headers = new HttpHeaders();
    if (isPlatformBrowser(this.platformId)) {
      const token = localStorage.getItem('token');
      if (token) {
        headers = headers.set('Authorization', `Bearer ${token}`);
      }
    }
    return headers;
  }

  // Fetch all products
  getAllProducts(): Observable<Product[]> {
    const headers = this.createAuthHeaders();
    return this.http.get<Product[]>(this.apiUrl, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Delete a product
  deleteProduct(id: string): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.delete<any>(`${this.apiUrl}/${id}`, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Edit a product
  editProduct(id: string, product: Product): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.put<any>(`${this.apiUrl}/${id}`, product, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Add a new product
  addProduct(product: Product): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post<any>(this.apiUrl, product, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Get product by ID
  getProductById(id: string): Observable<Product> {
    const headers = this.createAuthHeaders();
    return this.http.get<Product>(`${this.apiUrl}/${id}`, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Upload an image
  uploadImage(formData: FormData): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post<any>(this.uploadUrl, formData, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Search for products based on query
  searchProducts(query: string): Observable<Product[]> {
    const headers = this.createAuthHeaders();
    return this.http.get<Product[]>(`${this.apiUrl}/search?q=${query}`, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Error handling
  private handleError(error: HttpErrorResponse) {
    console.error('An error occurred:', error);
    return throwError(() => new Error('Something went wrong; please try again later.'));
  }
}
