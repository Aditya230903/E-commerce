import { Injectable } from '@angular/core'; 
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  private apiUrl = 'http://localhost:3000/api/orders';  // Backend API URL

  constructor(private http: HttpClient) {}

  // Get token from local storage
  private getToken(): string | null {
    return localStorage.getItem('token');
  }

  // Place an order
  placeOrder(orderData: any): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.post(`${this.apiUrl}/place-order`, orderData, { headers });
  }

  // Get all orders (Admin)
  getAllOrders(): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.get(`${this.apiUrl}/admin-orders`, { headers });
  }

  // Get user orders (User)
  getUserOrders(): Observable<any[]> {
    const headers = this.createAuthHeaders(); // Use the helper method to set headers
    return this.http.get<any[]>(`${this.apiUrl}/user-orders`, { headers });
  }
  

  // Update order status (Admin)
  updateOrderStatus(orderId: string, status: string): Observable<any> {
    const headers = this.createAuthHeaders();
    return this.http.put(`${this.apiUrl}/admin-orders/${orderId}`, { status }, { headers });
  }

  // Helper method to create headers with Authorization token
  private createAuthHeaders(): HttpHeaders {
    const token = this.getToken();
    return new HttpHeaders().set('Authorization', `Bearer ${token}`);
  }


  
}
