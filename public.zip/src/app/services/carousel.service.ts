import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CarouselService {
  private apiUrl = 'http://localhost:3000/carousel'; // Backend API URL

  constructor(private http: HttpClient) {}

  // Get carousel images
  getCarousel(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}`);
  }

  // Add new images to the carousel
  addCarouselImages(formData: FormData): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}`, formData);
  }

  // Update carousel images
  updateCarouselImages(images: string[]): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}`, { images });
  }

  // Delete images from carousel
  deleteCarouselImages(images: string[]): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}`, { body: { images } });
  }
}
