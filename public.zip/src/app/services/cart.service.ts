import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Product } from '../common/product';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private apiUrl = 'http://localhost:3000/api/cart';

  constructor(private http: HttpClient) {}

  // Add product to the cart on the backend
  addToCart(product: Product): Observable<any> {
    const token = this.getToken();  // Get the token from localStorage
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.post(this.apiUrl + '/add', { productId: product._id, quantity: 1 }, { headers });
  }
  
  // Get user's cart by user ID
  getCart(userId: string): Observable<any> {
    const token = this.getToken();  // Get the token from localStorage
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.get<any>(`${this.apiUrl}/${userId}`, { headers }); // Pass userId in URL
  }

  // Remove product from the cart
  removeFromCart(productId: string): Observable<any> {
    const token = this.getToken();
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.delete(`${this.apiUrl}/remove/${productId}`, { headers });
  }

  private getToken(): string | null {
    return localStorage.getItem('token');
  }
}
