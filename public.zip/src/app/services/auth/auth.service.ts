import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  getToken(): string | null {
    return localStorage.getItem('token');
  }
  
  private authUrl = 'http://localhost:3000/api/auth';

  public isLoggedInSubject = new BehaviorSubject<boolean>(this.hasToken());
  public isAdminSubject = new BehaviorSubject<boolean>(this.getAdminStatus());
  public userDataSubject = new BehaviorSubject<any>(this.getStoredUserData());

  isLoggedIn$ = this.isLoggedInSubject.asObservable();
  isAdmin$ = this.isAdminSubject.asObservable();
  userData$ = this.userDataSubject.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  register(user: { name: string; email: string; password: string; isAdmin?: boolean }): Observable<any> {
    return this.http.post(`${this.authUrl}/register`, user).pipe(
      map((response: any) => {
        if (response.token) {
          this.storeTokenData(response.token, response.user.isAdmin);
          this.setUserData(response.user);
        }
        return response;
      })
    );
  }

  login(credentials: { email: string; password: string }): Observable<any> {
    return this.http.post(`${this.authUrl}/login`, credentials).pipe(
      map((response: any) => {
        if (response.token) {
          this.storeTokenData(response.token, response.user.isAdmin);
          this.setUserData(response.user);
        }
        return response;
      })
    );
  }

  public setUserData(user: any): void {
    this.userDataSubject.next(user);
    this.setLocalStorage('userData', JSON.stringify(user));
  }

  public getAdminStatus(): boolean {
    const storedAdminStatus = this.getLocalStorage('isAdmin');
    return storedAdminStatus === 'true';
  }

  logout(): void {
    this.clearAuthData();
    this.router.navigate(['/login']);
  }

  private storeTokenData(token: string, isAdmin: boolean): void {
    this.setLocalStorage('token', token);
    this.setLocalStorage('isAdmin', isAdmin.toString());
    this.isLoggedInSubject.next(true);
    this.isAdminSubject.next(isAdmin);
  }

  private clearAuthData(): void {
    this.removeLocalStorage('token');
    this.removeLocalStorage('isAdmin');
    this.isLoggedInSubject.next(false);
    this.isAdminSubject.next(false);
    this.userDataSubject.next(null);
    this.removeLocalStorage('userData');
  }

  private hasToken(): boolean {
    return !!this.getLocalStorage('token');
  }

  private getStoredUserData(): any {
    return JSON.parse(this.getLocalStorage('userData') || '{}');
  }

  getUserId(): string | null {
    const userData = this.getStoredUserData();
    return userData?._id || null;  // Assuming the user ID is stored as `_id`
  }

  private getLocalStorage(key: string): string | null {
    return typeof window !== 'undefined' ? localStorage.getItem(key) : null;
  }

  private setLocalStorage(key: string, value: string): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem(key, value);
    }
  }

  private removeLocalStorage(key: string): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(key);
    }
  }

  getProfile(): Observable<any> {
    return this.http.get(`${this.authUrl}/profile`);
  }

  updateProfile(updatedInfo: any): Observable<any> {
    return this.http.put(`${this.authUrl}/profile`, updatedInfo).pipe(
      map((response: any) => {
        if (response.user) {
          this.setUserData(response.user);
        }
        return response;
      })
    );
  }
}
