import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './components/home/home.component';
import { CategoryFormComponent } from './components/manage/category-form/category-form.component';
import { HttpClientModule, provideHttpClient, withFetch } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './components/manage/header/header.component';
import { FooterComponent } from './components/manage/footer/footer.component';
import { ProductDetailsComponent } from './components/manage/product-details/product-details.component';
import { CategoriesComponent } from './components/manage/categories/categories.component';
import { CarouselUploadComponent } from './components/manage/carousel-upload/carousel-upload.component';
import { LoginComponent } from './components/auth/login/login.component';
import { RegisterComponent } from './components/auth/register/register.component';
import { AdminDashboardComponent } from './components/manage/admin-dashboard/admin-dashboard.component';
import { SearchResultsComponent } from './components/manage/search-results/search-results.component';
import { ProfileComponent } from './components/manage/profile/profile.component';
import { CartComponent } from './components/manage/cart/cart.component';
import { WishlistComponent } from './components/manage/wishlist/wishlist.component';
import { OrderComponent } from './components/manage/order/order.component';
import { AdminOrdersComponent } from './components/manage/admin-orders/admin-orders.component';
// import { OrderStatusComponent } from './components/manage/order-status/order-status.component';
import { UserOrdersComponent } from './components/manage/user-orders/user-orders.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CategoryFormComponent,
    HeaderComponent,
    FooterComponent,
    ProductDetailsComponent,
    CarouselUploadComponent,
    LoginComponent,
    RegisterComponent,
    AdminDashboardComponent,
    SearchResultsComponent,
    ProfileComponent,
    CartComponent,
    WishlistComponent,
    OrderComponent,
    AdminOrdersComponent,
    // OrderStatusComponent,
    UserOrdersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    CategoriesComponent  // Importing CategoriesComponent
  ],
  providers: [
    provideHttpClient(withFetch())
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
