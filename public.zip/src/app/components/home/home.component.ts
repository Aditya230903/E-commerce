import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../services/products.service';
import { CartService } from '../../services/cart.service';
import { WishlistService } from '../../services/wishlist.service';
import { Product } from '../../common/product';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  products: Product[] = [];
  loading: boolean = true;
  showAlert: boolean = false;
  alertMessage: string = '';
  userId: string | null = null;

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private wishlistService: WishlistService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.userId = this.authService.getUserId();
    this.fetchProducts();
  }

  fetchProducts(): void {
    this.loading = true;
    this.productService.getAllProducts().subscribe(
      (result: Product[]) => {
        this.products = result;
        this.loading = false;
      },
      (error: any) => {
        console.error('Error fetching products', error);
        alert('Error fetching products: ' + error.message);
        this.loading = false;
      }
    );
  }

  addToCart(product: Product) {
    this.cartService.addToCart(product).subscribe(
      () => {
        console.log(`Added ${product.name} to cart`);
        this.showAlertMessage(`Product "${product.name}" added to cart!`);
      },
      (error) => {
        console.error('Error adding product to cart', error);
      }
    );
  }

  addToWishlist(product: Product) {
    if (this.userId && product._id) {
      this.wishlistService.addProductToWishlist(this.userId, product._id).subscribe(
        () => {
          this.showAlertMessage(`Product "${product.name}" added to wishlist!`);
        },
        (error) => {
          console.error('Error adding product to wishlist', error);
        }
      );
    } else {
      console.error('User ID or Product ID is undefined.');
    }
  }

  buyNow(product: Product) {
    console.log(`Buying ${product.name}`);
    // Implement buy now functionality if needed
  }

  private showAlertMessage(message: string) {
    this.alertMessage = message;
    this.showAlert = true;

    // Hide the alert after 3 seconds
    setTimeout(() => {
      this.showAlert = false;
    }, 3000);
  }
}
