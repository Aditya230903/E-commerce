import { Component, OnInit } from '@angular/core';
import { OrderService } from '../../../services/order.service';
import { AuthService } from '../../../services/auth/auth.service';

@Component({
  selector: 'app-user-orders',
  templateUrl: './user-orders.component.html',
  styleUrls: ['./user-orders.component.css']
})
export class UserOrdersComponent implements OnInit {
  orders: any[] = [];
  errorMessage: string = '';

  constructor(private orderService: OrderService, private authService: AuthService) {}

  ngOnInit(): void {
    this.fetchUserOrders();
  }

  fetchUserOrders(): void {
    this.orderService.getUserOrders().subscribe({
      next: (response) => {
        this.orders = response;
      },
      error: (error) => {
        this.errorMessage = error.error?.message || 'Error fetching orders';
      }
    });
  }
}
