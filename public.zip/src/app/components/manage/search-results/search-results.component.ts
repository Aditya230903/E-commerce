import { Component, OnInit } from '@angular/core'; 
import { ActivatedRoute } from '@angular/router';
import { ProductService } from '../../../services/products.service';
import { Product } from '../../../common/product';

@Component({
  selector: 'app-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.css']
})
export class SearchResultsComponent implements OnInit {
  products: Product[] = [];
  searchQuery: string = '';
  loading: boolean = false;
  errorMessage: string = '';

  constructor(
    private route: ActivatedRoute,
    private productService: ProductService
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.searchQuery = params['q'] || '';
      this.searchProducts();
    });
  }

  searchProducts(): void {
    if (!this.searchQuery.trim()) {
      this.errorMessage = 'Please enter a search term.';
      return;
    }
    
    this.loading = true;
    this.productService.searchProducts(this.searchQuery).subscribe({
      next: (products) => {
        this.products = products;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching search results:', error);
        this.errorMessage = 'Failed to load products. Please try again later.';
        this.loading = false;
      }
    });
  }

  onAddToCart(product: Product): void {
    // Placeholder for cart integration
    console.log('Product added to cart:', product);
  }
}
