import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/auth/auth.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user: any;
  isEditMode: boolean = false;
  orderId: string | undefined; // Define orderId

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    this.getUserProfile();
  }

  getUserProfile(): void {
    this.authService.userData$.subscribe(user => {
      this.user = user;
      this.orderId = user?.orderId; // Assign orderId if available
    });
  }

  editProfile(): void {
    this.isEditMode = true;
  }

  saveProfile(updatedInfo: any): void {
    this.authService.updateProfile(updatedInfo).subscribe(
      (response) => {
        alert('Profile updated successfully!');
        this.user = response.user;
        this.orderId = response.user?.orderId; // Update orderId
        this.isEditMode = false;
      },
      (error) => {
        console.error('Error updating profile:', error);
      }
    );
  }

  cancelEdit(): void {
    this.isEditMode = false;
  }
}
