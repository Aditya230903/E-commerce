import { Component, inject, OnInit } from '@angular/core';
import { ProductService } from '../../../services/products.service';
import { BrandService } from '../../../services/brand.service';
import { CategoryService } from '../../../services/category.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Product } from '../../../common/product'; // Adjust the import path if needed

interface Brand {
  _id: string;
  name: string;
}

interface Category {
  _id: string;
  name: string;
}

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  products: Product[] = [];
  brands: Brand[] = [];
  categories: Category[] = [];
  displayedCount: number = 5;
  loading: boolean = true;
  editForm: Product = {
    _id: '', name: '', shortDescription: '', description: '', price: 0, discount: 0, images: [], categoryId: '', brandId: ''
  };
  editingProductId: string | null = null;

  productService = inject(ProductService);
  brandService = inject(BrandService);
  categoryService = inject(CategoryService);

  constructor() {}

  ngOnInit(): void {
    this.fetchProducts();
    this.fetchBrands();
    this.fetchCategories();
  }

  fetchProducts(): void {
    this.loading = true;
    this.productService.getAllProducts().subscribe(
      (result: Product[]) => {
        this.products = result;
        this.loading = false;
      },
      (error: any) => {
        console.error('Error fetching products', error);
        alert('Error fetching products: ' + error.message);
        this.loading = false;
      }
    );
  }

  fetchBrands(): void {
    this.brandService.getAllBrands().subscribe(
      (result: Brand[]) => {
        this.brands = result;
      },
      (error: any) => {
        console.error('Error fetching brands', error);
        alert('Error fetching brands: ' + error.message);
      }
    );
  }

  fetchCategories(): void {
    this.categoryService.getAllCategories().subscribe(
      (result: Category[]) => {
        this.categories = result;
      },
      (error: any) => {
        console.error('Error fetching categories', error);
        alert('Error fetching categories: ' + error.message);
      }
    );
  }

  getCategoryName(categoryId: string): string {
    const category = this.categories.find(category => category._id === categoryId);
    return category ? category.name : 'N/A';
  }

  deleteProduct(id: string | undefined): void {
    if (!id) {
      alert('Invalid product ID');
      return;
    }

    if (confirm('Are you sure you want to delete this product?')) {
      this.productService.deleteProduct(id).subscribe(
        () => {
          this.products = this.products.filter(product => product._id !== id);
          alert('Product deleted successfully.');
        },
        (error: any) => {
          console.error('Error deleting product', error);
          alert('Error deleting product: ' + error.message);
        }
      );
    }
  }

  startEditProduct(product: Product): void {
    this.editingProductId = product._id || null;
    this.editForm = { ...product };
  }

  editProduct(): void {
    if (!this.editingProductId) {
      alert('Invalid product ID');
      return;
    }

    const updatedProduct = { ...this.editForm };

    this.productService.editProduct(this.editingProductId, updatedProduct).subscribe(
      () => {
        alert('Product updated successfully.');
        this.fetchProducts();
        this.resetEditForm();
      },
      (error: any) => {
        console.error('Error updating product', error);
        alert('Error updating product: ' + error.message);
      }
    );
  }

  resetEditForm(): void {
    this.editingProductId = null;
    this.editForm = {
      _id: '', name: '', shortDescription: '', description: '', price: 0, discount: 0, images: [], categoryId: '', brandId: ''
    };
  }

  updateProductCount(event: Event): void {
    const selectElement = event.target as HTMLSelectElement;
    this.displayedCount = Number(selectElement.value);
  }

  getBrandName(brandId: string): string {
    const brand = this.brands.find(brand => brand._id === brandId);
    return brand ? brand.name : 'N/A';
  }
}
