import { Component, inject, OnInit } from '@angular/core';
import { ProductService } from '../../../services/products.service';
import { BrandService } from '../../../services/brand.service';
import { CategoryService } from '../../../services/category.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';

interface Product {
  _id?: string;
  name: string;
  shortDescription: string;
  description: string;
  price: number;
  discount: number;
  images: string[]; // Array of image URLs
  categoryId: string;
  brandId: string;
}

interface Brand {
  _id: string;
  name: string;
}

interface Category {
  _id: string;
  name: string;
}

@Component({
  selector: 'app-product-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent implements OnInit {
  productFormModel: Product = {
    name: '',
    shortDescription: '',
    description: '',
    price: 0,
    discount: 0,
    images: [],
    categoryId: '',
    brandId: ''
  };
  
  brands: Brand[] = [];
  categories: Category[] = [];
  isEditMode: boolean = false;
  productId: string | null = null;

  // For handling image uploads and URLs
  selectedFiles: File[] = [];
  imagePreviews: string[] = [];
  imageUrls: string = ''; // Comma separated URLs
  imageMethod: string = ''; // 'upload' or 'url'

  // Injected services
  productService = inject(ProductService);
  brandService = inject(BrandService);
  categoryService = inject(CategoryService);
  router = inject(Router);
  route = inject(ActivatedRoute);
  httpClient = inject(HttpClient);

  ngOnInit(): void {
    this.fetchBrands();
    this.fetchCategories();
    this.route.paramMap.subscribe(params => {
      this.productId = params.get('id');
      if (this.productId) {
        this.isEditMode = true;
        this.loadProduct();
      }
    });
  }

  /**
   * Fetch all brands from the backend
   */
  fetchBrands(): void {
    this.brandService.getAllBrands().subscribe(
      (result: Brand[]) => {
        this.brands = result;
      },
      (error: any) => {
        console.error('Error fetching brands', error);
        alert('Error fetching brands: ' + error.message);
      }
    );
  }

  /**
   * Fetch all categories from the backend
   */
  fetchCategories(): void {
    this.categoryService.getAllCategories().subscribe(
      (result: Category[]) => {
        this.categories = result;
      },
      (error: any) => {
        console.error('Error fetching categories', error);
        alert('Error fetching categories: ' + error.message);
      }
    );
  }

  /**
   * Load product details for editing
   */
  loadProduct(): void {
    this.productService.getProductById(this.productId!).subscribe(
      (product: Product) => {
        this.productFormModel = { ...product };
        // If the product has images, determine if they are online URLs or uploaded images
        // This logic depends on how your backend stores image URLs
        // For simplicity, assume all images are URLs
        // If you have metadata to distinguish, implement accordingly
      },
      (error: any) => {
        console.error('Error loading product', error);
        alert('Error loading product: ' + error.message);
        this.router.navigate(['/products']);
      }
    );
  }

  /**
   * Handle file selection for image uploads
   * @param event File input change event
   */
  onFileSelected(event: any): void {
    const files: FileList = event.target.files;
    if (files && files.length > 0) {
      // Convert FileList to Array
      const selected = Array.from(files);
      
      // Optional: Limit the number of uploads
      // if (this.selectedFiles.length + selected.length > MAX_FILES) { ... }

      // Add selected files to the array
      this.selectedFiles.push(...selected);

      // Generate image previews
      selected.forEach(file => {
        const reader = new FileReader();
        reader.onload = (e: any) => {
          this.imagePreviews.push(e.target.result);
        };
        reader.readAsDataURL(file);
      });

      // Reset the file input
      event.target.value = '';
    }
  }

  /**
   * Remove a selected image from the previews and files array
   * @param index Index of the image to remove
   */
  removeSelectedImage(index: number): void {
    this.selectedFiles.splice(index, 1);
    this.imagePreviews.splice(index, 1);
  }

  /**
   * Handle form submission for adding or editing a product
   */
  submitForm(): void {
    // Validate form inputs if necessary

    if (this.imageMethod === 'upload') {
      // Handle uploaded images only
      if (this.selectedFiles.length === 0) {
        alert('Please upload at least one image.');
        return;
      }

      const uploadObservables: Observable<any>[] = [];

      this.selectedFiles.forEach(file => {
        const formData = new FormData();
        formData.append('image', file, file.name);
        // Assuming your backend has an endpoint to upload a single image
        uploadObservables.push(this.productService.uploadImage(formData));
      });

      // Execute all upload requests in parallel
      forkJoin(uploadObservables).subscribe(
        (uploadResponses: any[]) => {
          // Extract URLs from the upload responses
          const uploadedImageUrls = uploadResponses.map(response => response.imageUrl);

          // Update the product form model
          this.productFormModel.images = uploadedImageUrls;

          // Proceed to add or edit the product
          this.processProductForm();
        },
        (error: any) => {
          console.error('Error uploading images', error);
          alert('Error uploading images: ' + error.message);
        }
      );
    } else if (this.imageMethod === 'url') {
      // Handle image URLs only
      // Split the comma-separated URLs into an array
      const onlineImageUrls = this.imageUrls
        .split(',')
        .map(url => url.trim())
        .filter(url => url.length > 0);

      if (onlineImageUrls.length === 0) {
        alert('Please provide at least one image URL.');
        return;
      }

      // Update the product form model
      this.productFormModel.images = onlineImageUrls;

      // Proceed to add or edit the product
      this.processProductForm();
    } else {
      alert('Please select an image input method.');
    }
  }

  /**
   * Process the form submission by adding or editing the product
   */
  processProductForm(): void {
    if (this.isEditMode) {
      this.productService.editProduct(this.productId!, this.productFormModel).subscribe(
        () => {
          alert('Product updated successfully.');
          this.router.navigate(['/products']);
        },
        (error: any) => {
          console.error('Error updating product', error);
          alert('Error updating product: ' + error.message);
        }
      );
    } else {
      this.productService.addProduct(this.productFormModel).subscribe(
        () => {
          alert('Product added successfully.');
          this.router.navigate(['/products']);
        },
        (error: any) => {
          console.error('Error adding product', error);
          alert('Error adding product: ' + error.message);
        }
      );
    }
  }
}
