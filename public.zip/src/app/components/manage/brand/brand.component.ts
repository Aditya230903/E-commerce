// brand.component.ts
import { Component, inject } from '@angular/core';
import { BrandService } from '../../../services/brand.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-brands',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './brand.component.html',
  styleUrls: ['./brand.component.css']
})
export class BrandsComponent {
  brands: any[] = [];
  displayedCount: number = 5;
  editForm = { value: { name: '' } };
  editingBrandId: string | null = null;
  brandService = inject(BrandService);

  constructor() {
    this.fetchBrands();
  }

  fetchBrands() {
    this.brandService.getAllBrands().subscribe(
      (result: any[]) => {
        this.brands = result;
        console.log('Fetched brands:', this.brands);
      },
      (error: any) => {
        console.error('Error fetching brands', error);
      }
    );
  }

  deleteBrand(id: string) {
    if (confirm('Are you sure you want to delete this brand?')) {
      this.brandService.deleteBrand(id).subscribe(
        () => {
          this.brands = this.brands.filter(brand => brand._id !== id);
          console.log('Brand deleted:', id);
          alert('Brand deleted successfully.');
        },
        (error: any) => {
          console.error('Error deleting brand', error);
        }
      );
    }
  }

  startEditBrand(brand: any) {
    this.editingBrandId = brand._id;
    this.editForm.value.name = brand.name;
    console.log('Editing brand:', brand);
  }

  editBrand() {
    if (this.editingBrandId) {
      this.brandService.editBrand(this.editingBrandId, { name: this.editForm.value.name }).subscribe(
        () => {
          console.log('Brand updated:', this.editingBrandId);
          alert('Brand updated successfully.');
          this.fetchBrands();
          this.editingBrandId = null;
          this.editForm.value.name = '';
        },
        (error: any) => {
          console.error('Error updating brand', error);
        }
      );
    }
  }

  showAddBrandModal() {
    const newBrandName = prompt('Enter brand name:');
    if (newBrandName) {
      this.brandService.addBrand({ name: newBrandName }).subscribe(
        () => {
          this.fetchBrands();
          console.log('Brand added:', newBrandName);
          alert('Brand added successfully.');
        },
        (error: any) => {
          console.error('Error adding brand', error);
        }
      );
    }
  }

  updateBrandCount(event: Event) {
    const selectElement = event.target as HTMLSelectElement;
    this.displayedCount = +selectElement.value;
    console.log('Updated displayed brand count to:', this.displayedCount);
  }
}
