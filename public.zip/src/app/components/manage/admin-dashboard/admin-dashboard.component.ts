import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  adminName: string | null = '';

  ngOnInit(): void {
    // You can fetch admin-specific data here, if needed
    this.adminName = localStorage.getItem('adminName') || 'Admin'; // Customize if you store the name
  }
}
