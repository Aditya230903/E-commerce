// import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { CarouselService } from '../../../services/carousel.service';
// import { Carousel } from '../../../common/carousel';

// @Component({
//   selector: 'app-carousel-upload',
//   templateUrl: './carousel-upload.component.html',
//   styleUrls: ['./carousel-upload.component.css']
// })
// export class CarouselUploadComponent implements OnInit {
//   images: string[] = [];
//   carouselForm: FormGroup;
//   selectedFiles: File[] = [];

//   constructor(
//     private carouselService: CarouselService,
//     private fb: FormBuilder
//   ) {
//     this.carouselForm = this.fb.group({
//       images: ['']
//     });
//   }

//   ngOnInit(): void {
//     this.loadCarouselImages();
//   }

//   // Load carousel images on init
//   loadCarouselImages(): void {
//     this.carouselService.getCarousel().subscribe((response) => {
//       this.images = response.images;
//     });
//   }

//   // Handle file input for new images
//   onFileSelect(event: any): void {
//     this.selectedFiles = Array.from(event.target.files);
//   }

//   // Upload selected files
//   onUpload(): void {
//     const formData = new FormData();
//     this.selectedFiles.forEach((file) => {
//       formData.append('images', file, file.name);
//     });

//     this.carouselService.addCarouselImages(formData).subscribe(() => {
//       this.loadCarouselImages(); // Refresh the images after upload
//     });
//   }

//   // Delete selected images
//   onDeleteImage(image: string): void {
//     this.carouselService.deleteCarouselImages([image]).subscribe(() => {
//       this.loadCarouselImages(); // Refresh the images after deletion
//     });
//   }
// }







import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CarouselService } from '../../../services/carousel.service';

@Component({
  selector: 'app-carousel-upload',
  templateUrl: './carousel-upload.component.html',
  styleUrls: ['./carousel-upload.component.css']
})
export class CarouselUploadComponent implements OnInit, OnDestroy {
  images: string[] = [];
  selectedFiles: File[] = [];
  currentIndex = 0; // Track the current active slide
  intervalId: any;  // Interval ID for auto-slide
  autoSlideDuration = 3000; // 3 seconds for each slide
  carouselForm: FormGroup;

  constructor(
    private carouselService: CarouselService,
    private fb: FormBuilder
  ) {
    this.carouselForm = this.fb.group({
      images: ['']
    });
  }

  ngOnInit(): void {
    this.loadCarouselImages();
    this.startAutoSlide(); // Start auto sliding when the component initializes
  }

  ngOnDestroy(): void {
    this.stopAutoSlide(); // Stop the auto slide when the component is destroyed
  }

  // Load carousel images from the service
  loadCarouselImages(): void {
    this.carouselService.getCarousel().subscribe(
      (response) => {
        if (response && response.images && response.images.length) {
          this.images = response.images;
          this.currentIndex = 0; // Start from the first image
          this.startAutoSlide();
        } else {
          console.error('No images returned from the server.');
        }
      },
      (error) => {
        console.error('Error loading carousel images:', error);
      }
    );
  }
  

  // Handle file input for new images
  onFileSelect(event: any): void {
    this.selectedFiles = Array.from(event.target.files);
  }

  // Upload selected files
  onUpload(): void {
    const formData = new FormData();
    this.selectedFiles.forEach((file) => {
      formData.append('images', file, file.name);
    });

    this.carouselService.addCarouselImages(formData).subscribe(() => {
      this.loadCarouselImages();
    });
  }

  // Delete images from the carousel
  onDeleteImage(image: string): void {
    this.carouselService.deleteCarouselImages([image]).subscribe(() => {
      this.loadCarouselImages();
    });
  }

  // Start auto sliding
  startAutoSlide(): void {
    if (this.images.length > 0 && typeof window !== 'undefined') {
      this.intervalId = setInterval(() => {
        this.nextSlide();
      }, this.autoSlideDuration);
    }
  }
  
  
  // Stop the auto sliding
  stopAutoSlide(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  // Move to the next slide
  nextSlide(): void {
    this.currentIndex = (this.currentIndex + 1) % this.images.length;
  }

  // Move to the previous slide
  prevSlide(): void {
    this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
  }

  // Manual slide control: stop auto-slide and move to next/prev
  onManualSlide(direction: 'next' | 'prev'): void {
    this.stopAutoSlide();
    direction === 'next' ? this.nextSlide() : this.prevSlide();
    
    // Restart auto-slide after a brief delay to avoid conflicts
    setTimeout(() => {
      this.startAutoSlide();
    }, 5000); // Restart after 5 seconds of inactivity
  }}  
