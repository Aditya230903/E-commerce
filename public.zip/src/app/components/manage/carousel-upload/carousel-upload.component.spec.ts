import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarouselUploadComponent } from './carousel-upload.component';

describe('CarouselUploadComponent', () => {
  let component: CarouselUploadComponent;
  let fixture: ComponentFixture<CarouselUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CarouselUploadComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CarouselUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
