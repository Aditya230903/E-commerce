import { Component, inject } from '@angular/core';
import { CategoryService } from '../../../services/category.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-categories',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent {
  categories: any[] = [];
  editForm = { value: { name: '' } };
  editingCategoryId: string | null = null;
  newCategoryName: string = ''; // For new category input
  showAddCategory: boolean = false; // Toggle to show add category form
  displayedCount: number = 5; // Default displayed count

  categoryService = inject(CategoryService);

  constructor() {
    console.log('CategoriesComponent initialized');
    this.fetchCategories();
  }

  // Fetch all categories from the server
  fetchCategories() {
    console.log('Fetching categories...');
    this.categoryService.getAllCategories().subscribe(
      (result: any[]) => {
        this.categories = result;
        console.log('Fetched categories:', this.categories);
      },
      (error: any) => {
        console.error('Error fetching categories', error);
      }
    );
  }

  // Delete a category
  deleteCategory(id: string) {
    console.log(`Attempting to delete category with ID: ${id}`);
    if (confirm('Are you sure you want to delete this category?')) {
      this.categoryService.deleteCategory(id).subscribe(
        () => {
          this.categories = this.categories.filter(category => category._id !== id);
          console.log('Category deleted successfully:', id);
          alert('Category deleted successfully.');
        },
        (error) => {
          console.error('Error deleting category', error);
        }
      );
    } else {
      console.log('Delete action canceled');
    }
  }

  // Start editing a category
  startEditCategory(category: any) {
    this.editingCategoryId = category._id;
    this.editForm.value.name = category.name;
    console.log('Editing category:', category);
  }

  // Save edited category
  editCategory() {
    if (this.editingCategoryId) {
      console.log(`Saving changes for category ID: ${this.editingCategoryId}, New Name: ${this.editForm.value.name}`);
      this.categoryService.editCategory(this.editingCategoryId, { name: this.editForm.value.name }).subscribe(
        () => {
          alert('Category updated successfully.');
          this.fetchCategories();
          this.editingCategoryId = null;
          this.editForm.value.name = '';
        },
        (error) => {
          console.error('Error updating category', error);
        }
      );
    }
  }

  // Show add category modal
  showAddCategoryModal() {
    this.showAddCategory = true; // Show the add category form
    console.log('Showing add category modal');
  }

  // Cancel adding a category
  cancelAddCategory() {
    this.showAddCategory = false; // Hide the add category form
    this.newCategoryName = ''; // Reset the input
    console.log('Canceled adding category');
  }

  // Add a new category
  addCategory() {
    if (this.newCategoryName.trim()) {
      console.log(`Adding new category: ${this.newCategoryName}`);
      this.categoryService.addCategory({ name: this.newCategoryName }).subscribe(
        () => {
          alert('Category added successfully.');
          this.fetchCategories(); // Refresh categories
          this.cancelAddCategory(); // Reset the form
        },
        (error: any) => {
          console.error('Error adding category', error);
        }
      );
    } else {
      alert('Please enter a category name.');
      console.warn('No category name provided for addition');
    }
  }

  // Update the displayed count of categories
  updateCategoryCount(event: any) {
    this.displayedCount = +event.target.value; // Ensure the value is a number
    console.log(`Updated displayed count to: ${this.displayedCount}`);
  }
}
