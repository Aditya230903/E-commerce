import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/auth/auth.service';
import { Router } from '@angular/router';
import { ProductService } from '../../../services/products.service';
import { Product } from '../../../common/product';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isLoggedIn: boolean = false;
  searchResults: Product[] = [];

  constructor(
    public authService: AuthService,
    private productService: ProductService,
    public router: Router
  ) {}

  ngOnInit(): void {
    this.authService.isLoggedIn$.subscribe((status) => {
      this.isLoggedIn = status;
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  searchProducts(query: string): void {
    if (query.trim()) {
      // Redirect to search results page with the query as a query parameter
      this.router.navigate(['/search'], { queryParams: { q: query } });
    } else {
      // Redirect to homepage when search box is cleared
      this.router.navigate(['/home']);
    }
  }
}
