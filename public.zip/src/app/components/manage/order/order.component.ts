import { Component } from '@angular/core';
import { OrderService } from '../../../services/order.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent {

  address: string = '';
  paymentMethod: string = '';
  productId: string = '';  // Product ID will be dynamically passed
  orderStatus: string = 'Pending';

  successMessage: string = ''; // Holds the success message
  errorMessage: string = ''; // Holds the error message

  constructor(private orderService: OrderService, private router: Router, private route: ActivatedRoute) {
    // Capture productId from the URL parameters
    this.route.params.subscribe(params => {
      this.productId = params['productId'];  // Get productId from the URL
    });
  }

  onOrderPlace(): void {
    const orderData = {
      productId: this.productId,
      address: this.address,
      paymentMethod: this.paymentMethod
    };
    
    this.orderService.placeOrder(orderData).subscribe(
      (response: any) => {
        console.log('Order placed successfully', response);
        this.successMessage = 'Your order has been successfully placed!';
        setTimeout(() => {
          this.router.navigate(['/order-success']);
        }, 3000); // 3 seconds delay
      },
      (error: any) => {
        console.error('Error placing order', error);
        this.errorMessage = 'Failed to place the order. Please try again later.';
      }
    );
  }
}
