import { Component, OnInit } from '@angular/core';
import { CarouselService } from '../../../services/carousel.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-carousel-list',
  templateUrl: './carousel-list.component.html',
  styleUrls: ['./carousel-list.component.css']
})
export class CarouselListComponent implements OnInit {
  images: string[] = [];
  selectedFiles: File[] = [];
  currentIndex = 0; // To track the current active slide
  carouselForm: FormGroup;

  constructor(
    private carouselService: CarouselService,
    private fb: FormBuilder
  ) {
    // Initialize the form group for handling file uploads
    this.carouselForm = this.fb.group({
      images: ['']
    });
  }

  ngOnInit(): void {
    // Load images for the carousel on component initialization
    this.loadCarouselImages();
  }

  loadCarouselImages(): void {
    this.carouselService.getCarousel().subscribe({
      next: (response) => {
        // Ensure that response.images is defined and is an array
        this.images = Array.isArray(response.images) ? response.images : [];
      },
      error: (err) => {
        console.error('Error loading carousel images', err);
      }
    });
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      this.selectedFiles = Array.from(input.files);
    }
  }

  onUpload(): void {
    const formData = new FormData();
    this.selectedFiles.forEach((file) => {
      formData.append('images', file, file.name);
    });

    this.carouselService.addCarouselImages(formData).subscribe({
      next: () => {
        // Refresh the image list after upload
        this.loadCarouselImages();
        // Clear the selected files after upload
        this.selectedFiles = [];
      },
      error: (err) => {
        console.error('Error uploading images', err);
      }
    });
  }

  onDeleteImage(image: string): void {
    this.carouselService.deleteCarouselImages([image]).subscribe({
      next: () => {
        // Refresh the image list after deletion
        this.loadCarouselImages();
      },
      error: (err) => {
        console.error('Error deleting image', err);
      }
    });
  }

  // nextSlide(): void {
  //   if (this.images.length) {
  //     this.currentIndex = (this.currentIndex + 1) % this.images.length;
  //   }
  // }

  // prevSlide(): void {
  //   if (this.images.length) {
  //     this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
  //   }
  // }
}
