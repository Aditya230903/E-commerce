import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { CartService } from '../../../services/cart.service';
import { CartItem } from '../../../common/cart-item';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: CartItem[] = [];

  constructor(private cartService: CartService, @Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit(): void {
    this.loadCart();
  }

  loadCart() {
    if (isPlatformBrowser(this.platformId)) {  // Check if running in the browser
      const userId = localStorage.getItem('userId');
      if (userId) {
        this.cartService.getCart(userId).subscribe(
          (data) => {
            this.cart = data.items;  // Adjust if the response structure changes
          },
          (error) => {
            console.error('Error fetching cart', error);
          }
        );
      } else {
        console.error('User ID not available');
      }
    }
  }

  getTotalPrice() {
    return this.cart.reduce((total, item) => {
      const price = this.isValidPrice(item.productId.price) ? item.productId.price : 0;
      return total + (price * item.quantity);
    }, 0);
  }

  isValidPrice(price: any): boolean {
    return !isNaN(price) && price >= 0;
  }

  removeFromCart(productId: string) {
    this.cartService.removeFromCart(productId).subscribe(
      () => {
        this.loadCart();  // Reload cart after removing the item
      },
      (error) => {
        console.error('Error removing product from cart', error);
      }
    );
  }
}
