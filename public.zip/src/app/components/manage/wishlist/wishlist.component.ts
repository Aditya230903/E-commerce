import { Component, OnInit } from '@angular/core';
import { WishlistService } from '../../../services/wishlist.service';
import { AuthService } from '../../../services/auth/auth.service';
import { Product } from '../../../common/product';

interface Wishlist {
  products: Product[];
}

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {
  wishlist: Wishlist = { products: [] };  // Initialize with an empty array
  userId: string | null = null;
  errorMessage: string | null = null;

  constructor(
    private wishlistService: WishlistService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.userId = this.authService.getUserId();
    if (this.userId) {
      this.loadWishlist();
    } else {
      this.errorMessage = 'You need to be logged in to view your wishlist.';
    }
  }

  // Load Wishlist for the user
  loadWishlist(): void {
    if (this.userId) {
      this.wishlistService.getWishlist(this.userId).subscribe(
        (data: Wishlist) => {
          this.wishlist = data || { products: [] };  // Ensure wishlist is not undefined
          this.errorMessage = null;
        },
        error => {
          console.error('Error fetching wishlist', error);
          this.errorMessage = 'Failed to load wishlist. Please try again later.';
        }
      );
    }
  }

  // Add product to Wishlist
  addProduct(productId: string): void {
    if (this.userId && productId) {
      this.wishlistService.addProductToWishlist(this.userId, productId).subscribe(  // Corrected method name
        () => {
          this.loadWishlist();  // Refresh the wishlist after adding the product
          this.errorMessage = null;
        },
        error => {
          console.error('Error adding product to wishlist', error);
          this.errorMessage = 'Failed to add product to wishlist.';
        }
      );
    } else {
      this.errorMessage = 'Product ID is invalid or user is not logged in.';
    }
  }

  // Remove product from Wishlist
  removeProduct(productId: string): void {
    if (this.userId && productId) {
      this.wishlistService.removeProductFromWishlist(this.userId, productId).subscribe(
        () => {
          this.loadWishlist();  // Refresh the wishlist after removing the product
          this.errorMessage = null;
        },
        error => {
          console.error('Error removing product from wishlist', error);
          this.errorMessage = 'Failed to remove product from wishlist.';
        }
      );
    } else {
      this.errorMessage = 'Product ID is invalid or user is not logged in.';
    }
  }
}
