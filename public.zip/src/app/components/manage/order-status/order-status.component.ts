// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';
// import { OrderService } from '../../../services/order.service';

// @Component({
//   selector: 'app-order-status',
//   templateUrl: './order-status.component.html',
//   styleUrls: ['./order-status.component.css']
// })
// export class OrderStatusComponent implements OnInit {
//   orderId: string = '';
//   orderStatus: string = '';
//   errorMessage: string = '';

//   constructor(private route: ActivatedRoute, private orderService: OrderService) {}

//   ngOnInit(): void {
//     // Retrieve the orderId from route parameters
//     this.route.paramMap.subscribe(params => {
//       const id = params.get('orderId');
//       if (id) {
//           this.orderId = id;
//           this.getOrderStatus(this.orderId);
//       } else {
//           this.errorMessage = 'Order ID is missing.';
//       }
//   });
  
//   }

//   // Fetch order status from the API
//   getOrderStatus(orderId: string): void {
//     this.orderService.getUserOrders(orderId).subscribe({
//       next: (orders) => {
//         const order = orders.find((o: any) => o._id === orderId);
//         if (order) {
//           this.orderStatus = order.status || 'Unknown status';
//         } else {
//           this.errorMessage = `Order with ID ${orderId} not found.`;
//         }
//       },
//       error: (error) => {
//         console.error('Error fetching order status:', error);
//         this.errorMessage = 'Error fetching order status. Please try again later.';
//       }
//     });
//   }
// }
