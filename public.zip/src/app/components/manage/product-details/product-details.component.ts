// src/app/components/product-details/product-details.component.ts
import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../../../services/products.service';
import { CartService } from '../../../services/cart.service'; // Import CartService
import { Product } from '../../../common/product';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  product: Product | undefined;
  selectedImage: string | undefined;
  
  // Conversion rate from USD to INR
  USD_TO_INR_RATE: number = 82; // Update this rate as needed

  // Inject services
  productService = inject(ProductService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  cartService = inject(CartService); // Inject CartService

  // Alert visibility
  showAlert: boolean = false;

  constructor() {}

  ngOnInit(): void {
    const productId = this.route.snapshot.paramMap.get('id');
    if (productId) {
      this.productService.getProductById(productId).subscribe(
        (result: Product) => {
          this.product = result;
          this.selectedImage = result.images[0]; // Default to the first image
        },
        (error: any) => console.error('Error fetching product details', error)
      );
    }
  }

  onThumbnailClick(image: string): void {
    this.selectedImage = image;
  }

  // Calculate price in INR after applying discount
  getPriceInINR(): number {
    if (!this.product) return 0;
    const discountedPrice = this.product.price * (1 - this.product.discount / 100);
    return discountedPrice * this.USD_TO_INR_RATE;
  }

  // Handle Buy Now button click
  onBuyNow(): void {
    if (this.product) {
      // Navigate to the checkout page or handle purchase logic
      this.router.navigate(['/checkout'], { queryParams: { productId: this.product._id } });
    }
  }

  // Handle Add to Cart button click
  onAddToCart(): void {
    if (this.product) {
      this.cartService.addToCart(this.product);
      this.showConfirmation();
    }
  }

  // Show confirmation alert
  showConfirmation(): void {
    this.showAlert = true;
    setTimeout(() => {
      this.showAlert = false;
    }, 3000); // Hide after 3 seconds
  }
}
