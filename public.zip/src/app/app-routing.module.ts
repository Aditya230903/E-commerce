import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { CategoriesComponent } from './components/manage/categories/categories.component';
import { CategoryFormComponent } from './components/manage/category-form/category-form.component';
import { ProductComponent } from './components/manage/product/product.component';
import { ProductFormComponent } from './components/manage/product-form/product-form.component';
import { BrandsComponent } from './components/manage/brand/brand.component';
import { ProductDetailsComponent } from './components/manage/product-details/product-details.component';
import { CarouselListComponent } from './components/manage/carousel-list/carousel-list.component';
import { RegisterComponent } from './components/auth/register/register.component';
import { LoginComponent } from './components/auth/login/login.component';
import { AdminDashboardComponent } from './components/manage/admin-dashboard/admin-dashboard.component';
import { AuthGuard } from '../app/auth.guard';
import { SearchResultsComponent } from './components/manage/search-results/search-results.component';
import { ProfileComponent } from './components/manage/profile/profile.component';
import { CartComponent } from './components/manage/cart/cart.component';
import { WishlistComponent } from './components/manage/wishlist/wishlist.component';
import { OrderComponent } from './components/manage/order/order.component';
import { AdminOrdersComponent } from './components/manage/admin-orders/admin-orders.component';
// import { OrderStatusComponent } from './components/manage/order-status/order-status.component'; // Import OrderStatusComponent
import { UserOrdersComponent } from './components/manage/user-orders/user-orders.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'product-details/:id', component: ProductDetailsComponent },
  { path: 'categories', component: CategoriesComponent },
  { path: 'category-form', component: CategoryFormComponent },
  { path: 'admin/products', component: ProductComponent },
  { path: 'product-form', component: ProductFormComponent },
  { path: 'brands', component: BrandsComponent },
  { path: 'admin/carousel-list', component: CarouselListComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'admin-dashboard', component: AdminDashboardComponent, canActivate: [AuthGuard] },
  { path: 'search', component: SearchResultsComponent },
  { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] },
  { path: 'cart', component: CartComponent, canActivate: [AuthGuard] },
  { path: 'wishlist', component: WishlistComponent, canActivate: [AuthGuard] },
  // { path: 'user-orders/:orderId', component: OrderStatusComponent, canActivate: [AuthGuard] },  // OrderStatus route
  { path: 'orders/:productId', component: OrderComponent, canActivate: [AuthGuard] },
  { path: 'admin-orders', component: AdminOrdersComponent, canActivate: [AuthGuard] },
  { path: 'user-orders/:orderId', component: UserOrdersComponent },


  { path: '**', redirectTo: '/home', pathMatch: 'full' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
