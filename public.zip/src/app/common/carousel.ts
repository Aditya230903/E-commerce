export interface Carousel {
  _id: string;
  images: string[];
  createdAt: string;
  updatedAt: string;
}
