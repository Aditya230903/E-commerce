import { Product } from './product';

export interface CartItem {
  productId: Product;  // This links to your full product details
  quantity: number;
}
