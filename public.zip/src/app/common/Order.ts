export interface ProductInOrder { 
    product: {
        _id: string;
        name: string;
        price: number;
        // Add other product properties as needed
    };
    quantity: number;
}
export interface Order {
    _id?: string;
    user: string; // User ID or name
    products: ProductInOrder[]; // List of products in the order
    totalPrice: number; // Total cost of the order
    status: string; // Order status (e.g., Pending, Shipped, Delivered)
    paymentMethod: string; // Payment method used for the order
    shippingAddress: {
        address: string;
        city: string;
        state: string;
        zip: string;
        country: string;
    };
    createdAt: string; // ISO date string for order creation
    updatedAt?: string; // Optional field for the last update timestamp
}

