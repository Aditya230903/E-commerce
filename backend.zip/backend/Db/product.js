const mongoose = require("mongoose");
const { Schema } = mongoose;

const productSchema = new mongoose.Schema({
    name: { type: String, required: true },
    shortDescription: { type: String },
    description: { type: String },
    price: { type: Number, required: true },
    discount: { type: Number },
    images: [{ type: String }],
    categoryId: { type: Schema.Types.ObjectId, ref: 'Category', required: true }, // Adjusted to 'Category'
    brandId: { type: Schema.Types.ObjectId, ref: 'Brand', required: true } // Adjusted to 'Brand'
});

const Product = mongoose.model("Product", productSchema); // Adjusted to match the collection name
module.exports = Product;
