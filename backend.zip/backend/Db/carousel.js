const mongoose = require("mongoose");
const { Schema } = mongoose;

const carouselSchema = new Schema({
    images: [String], // Array of strings (image file paths or URLs)
    filename: String   // New field to store the filename
}, { timestamps: true });

const Carousel = mongoose.model("Carousel", carouselSchema);

module.exports = Carousel;
