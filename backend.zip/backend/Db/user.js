const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  mobileNo: { type: String, required: true },
  street: { type: String },
  pin: { type: String },
  state: { type: String },
  country: { type: String },
  isAdmin: { type: Boolean, default: false } // Field for admin status
});

// Exclude the password field from the response
userSchema.methods.toJSON = function () {
  const user = this.toObject();
  delete user.password;
  return user;
};

module.exports = mongoose.model("User", userSchema);
