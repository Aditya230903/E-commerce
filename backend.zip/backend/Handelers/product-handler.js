const mongoose = require("mongoose");
const Product = require("../Db/product");

async function AddProduct(data) {
    try {
        const product = new Product(data);
        await product.save();
        return product.toObject();
    } catch (error) {
        throw new Error(`Error adding product: ${error.message}`);
    }
}

async function updateProduct(id, data) {
    try {
        await Product.findByIdAndUpdate(id, data);
    } catch (error) {
        throw new Error(`Error updating product: ${error.message}`);
    }
}

async function deleteProduct(id) {
    try {
        await Product.findByIdAndDelete(id);
    } catch (error) {
        throw new Error(`Error deleting product: ${error.message}`);
    }
}

async function getAllProducts({ page = 1, limit = 20 }) {
    try {
        const skip = (page - 1) * limit;
        const products = await Product.find().skip(skip).limit(limit);
        return products.map(product => product.toObject());
    } catch (error) {
        throw new Error(`Error fetching products: ${error.message}`);
    }
}

async function getProduct(id) {
    try {
        const product = mongoose.Types.ObjectId.isValid(id)
            ? await Product.findById(id)
            : await Product.findOne({ $or: [{ name: new RegExp(id, "i") }, { description: new RegExp(id, "i") }] });
        
        return product ? product.toObject() : null;
    } catch (error) {
        throw new Error(`Error fetching product: ${error.message}`);
    }
}

async function searchProducts(query) {
    try {
        return await Product.find({
            $or: [
                { name: { $regex: query, $options: "i" } },
                { description: { $regex: query, $options: "i" } }
            ]
        });
    } catch (error) {
        throw new Error(`Error during product search: ${error.message}`);
    }
}

async function getRelatedProducts(categoryId, { page = 1, limit = 10 }) {
    try {
        if (!mongoose.Types.ObjectId.isValid(categoryId)) {
            throw new Error('Invalid categoryId provided.');
        }
        
        const skip = (page - 1) * limit;
        const products = await Product.find({ categoryId }).skip(skip).limit(limit);
        
        return products.map(product => product.toObject());
    } catch (error) {
        throw new Error(`Error fetching related products: ${error.message}`);
    }
}

module.exports = {
    AddProduct,
    updateProduct,
    deleteProduct,
    getAllProducts,
    getProduct,
    searchProducts,
    getRelatedProducts
};
