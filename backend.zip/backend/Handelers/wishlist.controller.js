const Wishlist = require('../Db/wishlist');

exports.getWishlist = async (req, res) => {
    try {
        // Correct the check for user authentication
        if (req.user._id.toString() === req.params.userId || req.user.isAdmin) {
            const wishlist = await Wishlist.findOne({ user: req.params.userId }).populate('products');
            if (!wishlist) {
                return res.status(404).json({ message: 'Wishlist not found' });
            }
            return res.status(200).json(wishlist);
        } else {
            return res.status(403).json({ message: 'Access forbidden' });
        }
    } catch (error) {
        console.error("Error fetching wishlist:", error.message);
        return res.status(500).json({ message: 'Server error', error });
    }
};

exports.addProductToWishlist = async (req, res) => {
    const { userId, productId } = req.body;

    try {
        let wishlist = await Wishlist.findOne({ user: userId });
        if (!wishlist) {
            wishlist = new Wishlist({ user: userId, products: [productId] });
        } else if (!wishlist.products.includes(productId)) {
            wishlist.products.push(productId);
        }
        await wishlist.save();
        res.json(wishlist);
    } catch (error) {
        console.error("Failed to add to wishlist:", error.message);
        res.status(500).json({ error: 'Failed to add to wishlist' });
    }
};

exports.removeProductFromWishlist = async (req, res) => {
    const { userId, productId } = req.body;

    try {
        const wishlist = await Wishlist.findOne({ user: userId });
        if (wishlist) {
            wishlist.products.pull(productId); // Remove the product from the array
            await wishlist.save();  // Save the updated wishlist
            res.json(wishlist);
        } else {
            return res.status(404).json({ error: 'Wishlist not found' });
        }
    } catch (error) {
        console.error("Failed to remove from wishlist:", error.message);
        res.status(500).json({ error: 'Failed to remove from wishlist' });
    }
};
