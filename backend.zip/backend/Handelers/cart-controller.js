const Cart = require('../Db/cart');
const Product = require('../Db/product');

// Add a single product to the cart
exports.addToCart = async (req, res) => {
  try {
    const { productId, quantity } = req.body;
    const userId = req.user._id;  // Changed from req.userId

    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    let cart = await Cart.findOne({ userId });

    if (cart) {
      const productIndex = cart.products.findIndex((p) => p.productId.toString() === productId);

      if (productIndex > -1) {
        cart.products[productIndex].quantity += quantity;
      } else {
        cart.products.push({ productId, quantity });
      }
    } else {
      cart = new Cart({
        userId,
        products: [{ productId, quantity }],
      });
    }

    await cart.save();
    res.status(200).json({ message: 'Product added to cart', cart });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: 'Error adding product to cart', error: error.message });
  }
};

// Add multiple products to the cart
exports.addMultipleProductsToCart = async (req, res) => {
  try {
    const { products } = req.body;
    const userId = req.user._id;  // Changed from req.userId

    let cart = await Cart.findOne({ userId });

    if (!cart) {
      cart = new Cart({ userId, products: [] });
    }

    for (const item of products) {
      const { productId, quantity } = item;

      const product = await Product.findById(productId);
      if (!product) {
        return res.status(404).json({ message: `Product with ID ${productId} not found` });
      }

      const productIndex = cart.products.findIndex((p) => p.productId.toString() === productId);

      if (productIndex > -1) {
        cart.products[productIndex].quantity += quantity;
      } else {
        cart.products.push({ productId, quantity });
      }
    }

    await cart.save();
    res.status(200).json({ message: 'Products added to cart', cart });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: 'Error adding products to cart', error: error.message });
  }
};

// Get user's cart
exports.getCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.user._id }).populate('products.productId');  // Changed from req.userId
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    res.status(200).json({ items: cart.products });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: 'Error fetching cart', error: error.message });
  }
};

// Remove product from cart
exports.removeFromCart = async (req, res) => {
  try {
    const { productId } = req.params;
    const cart = await Cart.findOne({ userId: req.user._id });  // Changed from req.userId

    if (cart) {
      cart.products = cart.products.filter((p) => p.productId.toString() !== productId);
      await cart.save();
      res.status(200).json({ message: 'Product removed from cart' });
    } else {
      res.status(404).json({ message: 'Cart not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Error removing product from cart', error: error.message });
  }
};

// Clear the entire cart
exports.clearCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.user._id });  // Changed from req.userId

    if (cart) {
      cart.products = [];
      await cart.save();
      res.status(200).json({ message: 'Cart cleared' });
    } else {
      res.status(404).json({ message: 'Cart not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Error clearing cart', error: error.message });
  }
};
