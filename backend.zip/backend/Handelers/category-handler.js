const Category = require("./../Db/category");

async function addCategory(model) {
  const category = new Category({
    name: model.name,
  });
  await category.save();
  return category.toObject();
}

async function updateCategory(id, model) {
  await Category.findByIdAndUpdate(id, model, { new: true }); // Added options for returning the updated document
  return;
}

async function deleteCategory(id) {
  await Category.findByIdAndDelete(id);
  return;
}

async function getAllCategories() {
  const categories = await Category.find({});
  return categories;
}

module.exports = { addCategory, updateCategory, deleteCategory, getAllCategories };
