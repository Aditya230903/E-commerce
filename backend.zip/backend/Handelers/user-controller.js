const User = require("../Db/user");
const Cart = require("../Db/cart");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

exports.register = async (req, res) => {
  try {
    const { name, email, password, isAdmin = false, mobileNo, street, pin, state, country } = req.body;

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user
    const user = new User({ name, email, password: hashedPassword, isAdmin, mobileNo, street, pin, state, country });

    // Save the user to the database
    await user.save();

    // Create a cart for the new user
    const cart = new Cart({ userId: user._id, products: [] });
    await cart.save();

    res.status(201).json({
      message: "User registered successfully",
      cartId: cart._id,
      user: user.toJSON(),  // Include user data
    });
  } catch (error) {
    res.status(500).json({ error: "Registration failed", details: error.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user by email
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    // Generate a JWT token for the user
    const token = jwt.sign(
      { userId: user._id, isAdmin: user.isAdmin },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    // Find user's cart
    const cart = await Cart.findOne({ userId: user._id });
    if (!cart) {
      return res.status(404).json({ message: "Cart not found" });
    }

    res.json({
      message: "Logged in successfully",
      token,
      user: user.toJSON(),
      cartId: cart._id,  // Include cart ID in the response
    });
  } catch (error) {
    res.status(500).json({ error: "Login failed", details: error.message });
  }
};

exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);  // Return the user's profile (excluding password due to toJSON method)
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve user profile", details: error.message });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const { name, mobileNo, street, pin, state, country } = req.body;

    // Find user by ID
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Update the user's information
    user.name = name || user.name;
    user.mobileNo = mobileNo || user.mobileNo;
    user.street = street || user.street;
    user.pin = pin || user.pin;
    user.state = state || user.state;
    user.country = country || user.country;

    // Save the updated user
    await user.save();

    res.json({
      message: "Profile updated successfully",
      user: user.toJSON(),
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to update profile", details: error.message });
  }
};

exports.logout = (req, res) => {
  res.status(200).json({ message: "Logged out successfully" });
};
