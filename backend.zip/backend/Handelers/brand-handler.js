const Brand = require("./../Db/brand");

async function addBrand(model) {
  const brand = new Brand({
    name: model.name,
  });
  await brand.save();
  return brand.toObject();
}

async function updateBrand(id, model) {
  await Brand.findByIdAndUpdate(id, model, { new: true });
  return;
}

async function deleteBrand(id) {
  await Brand.findByIdAndDelete(id);
  return;
}

async function getAllBrands() {
  const brands = await Brand.find({});
  return brands;
}

module.exports = { addBrand, updateBrand, deleteBrand, getAllBrands };
