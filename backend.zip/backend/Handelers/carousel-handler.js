const Carousel = require("../Db/carousel");

async function getSingleCarousel() {
    let carousel = await Carousel.findOne(); // Fetch the only carousel
    if (!carousel) {
        console.log("No carousel found, creating a new one.");
        carousel = new Carousel(); // Create a new carousel if it doesn't exist
        await carousel.save();
    }
    return carousel;
}

async function AddCarouselImages(model) {
    console.log("AddCarouselImages called with model:", model);
    const carousel = await getSingleCarousel(); // Get or create the single carousel

    // Ensure only filenames are stored in the database
    carousel.images.push(...model.images); // Add new images to the existing carousel
    await carousel.save();
    
    console.log("Images added to carousel:", carousel);
    return carousel.toObject();
}

async function updateCarouselImages(images) {
    console.log("updateCarouselImages called with images:", images);
    const carousel = await getSingleCarousel(); // Get the only carousel

    // Update the images array
    carousel.images = images; // Replace with new images
    await carousel.save();
    console.log("Carousel images updated successfully");
}

async function deleteCarouselImages(imagesToDelete) {
    console.log("deleteCarouselImages called with images:", imagesToDelete);
    const carousel = await getSingleCarousel(); // Get the only carousel

    // Filter out the images to delete
    carousel.images = carousel.images.filter(image => !imagesToDelete.includes(image));
    await carousel.save();
    console.log("Images deleted from carousel successfully");
}

async function getAllCarousels() {
    const carousel = await getSingleCarousel(); // Get the only carousel
    console.log("Fetched carousel:", carousel);
    
    // Construct the correct image URLs
    const updatedCarousel = {
        ...carousel.toObject(),
        images: carousel.images.map(image => `http://localhost:3000/upload/carousel/${image}`) // Use correct path
    };

    return updatedCarousel;
}

module.exports = { 
    AddCarouselImages, 
    updateCarouselImages, 
    deleteCarouselImages, 
    getAllCarousels 
};
