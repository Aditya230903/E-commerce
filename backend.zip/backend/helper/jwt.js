const jwt = require("jsonwebtoken");

// Token verification and user details extraction middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Get the token from Authorization header

  if (!token) {
      console.error("No token provided");
      return res.status(401).json({ error: "Access denied. No token provided." });
  }

  console.log("Token provided:", token);

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
      if (err) {
          console.error("JWT verification error:", err.message);
          return res.status(403).json({ error: "Failed to authenticate token. Token may be expired or invalid." });
      }

      if (!decoded.userId || typeof decoded.isAdmin !== 'boolean') {
          console.error("Decoded token missing necessary fields");
          return res.status(403).json({ error: "Invalid token payload structure." });
      }

      req.user = {
          _id: decoded.userId,
          isAdmin: decoded.isAdmin || false,
      };

      console.log("Decoded User ID:", req.user._id, "| Is Admin:", req.user.isAdmin);
      next();
  });
};

// Middleware for admin access
const authorizeAdmin = (req, res, next) => {
  if (!req.user || !req.user.isAdmin) {
    console.error("Unauthorized access attempt by non-admin user.");
    return res.status(403).json({ error: "Access restricted to admin users only." });
  }

  console.log("Admin access granted to user:", req.user._id);
  next();
};

module.exports = { authenticateToken, authorizeAdmin };
