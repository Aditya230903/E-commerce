const express = require("express");
const router = express.Router();
const { addCategory, updateCategory, deleteCategory, getAllCategories } = require("../Handelers/category-handler");

router.post("", async (req, res) => {
  try {
    const model = req.body;
    const result = await addCategory(model);
    res.status(201).send(result);
  } catch (error) {
    res.status(500).send({ message: "Error adding category", error });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const model = req.body;
    const id = req.params["id"];
    await updateCategory(id, model);
    res.send({ message: "Updated successfully" });
  } catch (error) {
    res.status(500).send({ message: "Error updating category", error });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = req.params["id"];
    await deleteCategory(id);
    res.send({ message: "Deleted successfully" });
  } catch (error) {
    res.status(500).send({ message: "Error deleting category", error });
  }
});

router.get("", async (req, res) => {
  try {
    const categories = await getAllCategories();
    res.send(categories);
  } catch (error) {
    res.status(500).send({ message: "Error fetching categories", error });
  }
});

module.exports = router;
