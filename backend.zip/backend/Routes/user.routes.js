const express = require('express');
const router = express.Router();
const { register, login, getProfile, updateProfile, logout } = require('../Handelers/user-controller');
const { authenticateToken, authorizeAdmin } = require('../helper/jwt');

// User Registration Route
router.post('/register', register);

// User Login Route
router.post('/login', login);

// User Profile Routes (Requires Authentication)
router.get('/profile', authenticateToken, getProfile);
router.put('/profile', authenticateToken, updateProfile);

// Logout Route
router.post('/logout', authenticateToken, logout);

module.exports = router;
