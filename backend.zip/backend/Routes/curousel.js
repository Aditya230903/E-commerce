const express = require("express");
const multer = require("multer");
const path = require("path");
const {
    AddCarouselImages,
    updateCarouselImages,
    deleteCarouselImages,
    getAllCarousels 
} = require("../Handelers/carousel-handler");

const router = express.Router();

// Set up storage for file uploads
const uploadDir = path.join(__dirname, '../public/uploads/carousel');
const storage = multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

// File filter for only image files
const fileFilter = (req, file, cb) => {
    if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
        cb(null, true);
    } else {
        cb(new Error("Unsupported file type, only JPEG and PNG are allowed!"), false);
    }
};

// Use Multer to handle file uploads
const upload = multer({
    storage: storage,
    limits: { fileSize: 1024 * 1024 * 5 },
    fileFilter: fileFilter
});

// Route to handle adding images to the existing carousel
router.post("/", upload.array("images", 5), async (req, res) => {
    console.log("POST / - Request to add new images to carousel received");

    if (!req.files || req.files.length === 0) {
        console.log("No files uploaded");
        return res.status(400).json({ message: "No files uploaded!" });
    }

    const filePaths = req.files.map(file => file.filename);
    console.log("File paths:", filePaths);

    const model = {
        images: filePaths
    };

    try {
        let carousel = await AddCarouselImages(model);
        console.log("Images added to carousel:", carousel);
        res.status(201).json(carousel);
    } catch (error) {
        console.log("Error while adding images to carousel:", error.message);
        res.status(500).json({ error: error.message });
    }
});

// Route to update images in the carousel
router.put("/", async (req, res) => {
    console.log("PUT / - Request to update carousel images received");

    const { images } = req.body; // Assuming images are sent in the body
    try {
        await updateCarouselImages(images);
        res.status(200).json({ message: "Carousel images updated successfully" });
    } catch (error) {
        console.log("Error while updating carousel images:", error.message);
        res.status(500).json({ error: error.message });
    }
});

// Route to delete images from the carousel
router.delete("/", async (req, res) => {
    console.log("DELETE / - Request to delete images from carousel received");

    const { images } = req.body; // Assuming images to delete are sent in the body
    try {
        await deleteCarouselImages(images);
        res.status(200).json({ message: "Images deleted from carousel successfully" });
    } catch (error) {
        console.log("Error while deleting images from carousel:", error.message);
        res.status(500).json({ error: error.message });
    }
});

// Route to get the single carousel
router.get("/", async (req, res) => {
    console.log("GET / - Request to get the carousel");

    try {
        const carousel = await getAllCarousels();
        res.status(200).json(carousel);
    } catch (error) {
        console.log("Error while fetching carousel:", error.message);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
