const express = require('express');
const router = express.Router();
const { getWishlist, addProductToWishlist, removeProductFromWishlist } = require('../Handelers/wishlist.controller');
const { authenticateToken } = require('../helper/jwt');

// Get wishlist for a user
router.get('/:userId', authenticateToken, getWishlist);

// Add a product to the wishlist
router.post('/add', authenticateToken, addProductToWishlist);

// Remove a product from the wishlist
router.delete('/remove', authenticateToken, removeProductFromWishlist);

module.exports = router;
