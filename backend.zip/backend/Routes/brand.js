const express = require("express");
const router = express.Router();
const brandHandler = require("../Handelers/brand-handler");

router.get("/", async (req, res) => {
  try {
    const brands = await brandHandler.getAllBrands();
    res.json(brands);
  } catch (error) {
    res.status(500).json({ message: "Error fetching brands", error });
  }
});

router.post("/", async (req, res) => {
  try {
    const brand = await brandHandler.addBrand(req.body);
    res.status(201).json(brand);
  } catch (error) {
    res.status(400).json({ message: "Error creating brand", error });
  }
});

router.put("/:id", async (req, res) => {
  try {
    await brandHandler.updateBrand(req.params.id, req.body);
    res.status(200).json({ message: "Brand updated successfully" });
  } catch (error) {
    res.status(400).json({ message: "Error updating brand", error });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    await brandHandler.deleteBrand(req.params.id);
    res.status(200).json({ message: "Brand deleted successfully" });
  } catch (error) {
    res.status(400).json({ message: "Error deleting brand", error });
  }
});

module.exports = router;
