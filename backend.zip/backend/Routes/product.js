const express = require("express");
const {
    AddProduct,
    updateProduct,
    deleteProduct,
    getProduct,
    getAllProducts,
    searchProducts,
    getRelatedProducts
} = require("../Handelers/product-handler"); // Ensure path and names match your actual structure
const { authenticateToken, authorizeAdmin } = require("../helper/jwt");

const router = express.Router();

// Add a new product - Admin-only
router.post("/", authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        console.log("Add Product Request Body:", req.body); // Debugging log
        const product = await AddProduct(req.body);
        res.status(201).json(product);
    } catch (error) {
        console.error("Error adding product:", error.message);
        res.status(500).json({ error: "Failed to add product", details: error.message });
    }
});

// Update a product - Admin-only
router.put("/:id", authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        console.log("Update Product Request - ID:", req.params.id, "Body:", req.body);
        await updateProduct(req.params.id, req.body);
        res.json({ message: "Product updated successfully" });
    } catch (error) {
        console.error("Error updating product:", error.message);
        res.status(500).json({ error: "Failed to update product", details: error.message });
    }
});

// Delete a product - Admin-only
router.delete("/:id", authenticateToken, authorizeAdmin, async (req, res) => {
    try {
        console.log("Delete Product Request - ID:", req.params.id);
        await deleteProduct(req.params.id);
        res.json({ message: "Product deleted successfully" });
    } catch (error) {
        console.error("Error deleting product:", error.message);
        res.status(500).json({ error: "Failed to delete product", details: error.message });
    }
});

// Search products by name or description
router.get("/search", async (req, res) => {
    const query = req.query.q;
    if (!query) {
        return res.status(400).json({ error: "Search query is required" });
    }

    try {
        console.log("Search Query:", query);
        const products = await searchProducts(query);
        if (products.length === 0) {
            return res.status(404).json({ error: "No products found" });
        }
        res.json(products);
    } catch (error) {
        console.error("Error during product search:", error.message);
        res.status(500).json({ error: "Server error", details: error.message });
    }
});

// Get a single product by ID
router.get("/:id", async (req, res) => {
    try {
        console.log("Get Product Request - ID:", req.params.id);
        const product = await getProduct(req.params.id);
        if (!product) {
            return res.status(404).json({ error: "Product not found" });
        }
        res.json(product);
    } catch (error) {
        console.error("Error retrieving product:", error.message);
        res.status(500).json({ error: "Failed to retrieve product", details: error.message });
    }
});

// Get related products by category ID with pagination
router.get("/related/:categoryId", async (req, res) => {
    const { categoryId } = req.params;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;

    try {
        console.log("Get Related Products - Category ID:", categoryId, "Page:", page, "Limit:", limit);
        const products = await getRelatedProducts(categoryId, { page, limit });
        if (products.length === 0) {
            return res.status(404).json({ error: "No related products found" });
        }
        res.json(products);
    } catch (error) {
        console.error("Error retrieving related products:", error.message);
        res.status(500).json({ error: "Server error", details: error.message });
    }
});

// Get all products with pagination
router.get("/", async (req, res) => {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 20;

    try {
        console.log("Get All Products Request - Page:", page, "Limit:", limit);
        const products = await getAllProducts({ page, limit });
        res.json(products);
    } catch (error) {
        console.error("Error retrieving all products:", error.message);
        res.status(500).json({ error: "Failed to retrieve products", details: error.message });
    }
});

module.exports = router;
