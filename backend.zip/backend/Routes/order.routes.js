const express = require('express');
const router = express.Router();
const { authenticateToken, authorizeAdmin } = require('../helper/jwt'); // Import updated middleware functions
const orderController = require('../Handelers/order.controller');

// User routes
router.post('/place-order', authenticateToken, orderController.placeOrder); // User places order
router.get('/user-orders', authenticateToken, orderController.getUserOrders); // User sees their orders

// Admin routes
router.get('/admin-orders', authenticateToken, authorizeAdmin, orderController.getAllOrders); // Admin sees all orders
router.put('/admin-orders/:id', authenticateToken, authorizeAdmin, orderController.updateOrderStatus); // Admin updates order status

module.exports = router;
