const express = require('express');
const router = express.Router();
const cartController = require('../Handelers/cart-controller');
const { authenticateToken } = require('../helper/jwt');

// Add a single product to the cart
router.post('/add', authenticateToken, cartController.addToCart);

// Add multiple products to the cart
router.post('/add-multiple', authenticateToken, cartController.addMultipleProductsToCart);

// Get cart items by user ID
router.get('/:userId', authenticateToken, cartController.getCart);

// Remove a product from the cart
router.delete('/remove/:productId', authenticateToken, cartController.removeFromCart);

// Clear the entire cart
router.delete('/clear', authenticateToken, cartController.clearCart);

module.exports = router;
