require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");

// Route Imports
const categoryRoutes = require("./Routes/category");
const brandRoutes = require("./Routes/brand");
const productRoutes = require("./Routes/product");
const carouselRoutes = require("./Routes/curousel");
const authRoutes = require("./Routes/user.routes");
const cartRoutes = require("./Routes/cart");
const wishlistRoutes = require('./Routes/wishlist');
const orderRoutes = require('./Routes/order.routes');

// Middlewares
const { authenticateToken, authorizeAdmin } = require("./helper/jwt");

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use('/upload/carousel', express.static(path.join(__dirname, 'public/uploads/carousel')));

// Basic Route to confirm server is running
app.get("/", (req, res) => {
  res.send("Server running");
});

// API Routes
app.use("/category", categoryRoutes);
app.use("/brands", brandRoutes);
app.use("/product", productRoutes); // Product routes (also handles search)
app.use("/carousel", carouselRoutes);
app.use("/api/auth", authRoutes); // User authentication routes

// Protected Cart Routes (authentication required)
app.use("/api/cart", authenticateToken, cartRoutes); // Authentication middleware applied to cart routes

// Wishlist routes (authentication required)
app.use(`${process.env.API_URL}/wishlist`, authenticateToken, wishlistRoutes);

// Order Routes
app.use('/api/orders', orderRoutes);

// Connect to MongoDB and Start the Server
async function connectAndStartServer() {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      dbName: "my_shop",  // Retain this to specify your database name
    });
    console.log("Connected to MongoDB");

    app.listen(port, () => {
      console.log(`Server is listening on port ${port}`);
    });
  } catch (err) {
    console.error("MongoDB connection error:", err);
  }
}

connectAndStartServer();
